/********************************************************************* 
  Name: Caden Austin             NetID: CBA169 
  Course: CSE 4714              Assignment: Lab 2
  Programming Environment: Linux/VSCODE
  Purpose of File: Contains the parsing headers
*********************************************************************/

extern int nextToken;

// Function forward declarations
int lex();
void sentence();
